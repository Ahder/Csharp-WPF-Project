﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3
{
    /// ceci est une classe per pour la methode get , set et l'utiliser pour la classe main

    public class per
    {
        public string nom { get; set; }
        public string prenom { get; set; }
        public per (String nom,String prenom)
        {
            this.nom = nom;
            this.prenom = prenom;
        }

    }
}
