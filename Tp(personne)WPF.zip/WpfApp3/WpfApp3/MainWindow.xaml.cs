﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// ceci est une classe main on a creer une observablecollection qui resemble a une liste meme  s'il ya une 
    /// une petite difference 
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<per> persons;
        public MainWindow()
        {
            InitializeComponent();
            persons = new ObservableCollection<per>()
            {
                new per("bedjaoui","hichem"),
                new per("benzine","redha"),
                new per("miguel","miguel"),
                new per("benmansour","hanane")
              
            };
            listView.ItemsSource = persons;
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            persons.Add(new per(textBox.Text,textBox_Copy.Text));
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            persons.RemoveAt(listView.SelectedIndex);
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

